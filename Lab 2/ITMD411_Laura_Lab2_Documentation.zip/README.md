Project: Bank Record Generations
-------------------------------------
Objective: Write a program that will read and process bank data from a CSV file.
-------------------------------------------------------------------------------------
Description: Bank of IIT has gotten their hands on some interesting data which will allow for possible loans to various clients from various regions.

Accompanying the labs specs is a csv (comma separated value) file named 
bank-Detail.csv which contains valuable raw data to allow the bank to process loans based on client details from the file.

You need to parse the data and print record data for future loan considerations.
