package app;

public abstract class Client {

    //First method: readData()
    public abstract void readData();

    //Second method: processData()
    public abstract void processData();

    //Third method: printData();
    public abstract void printData();
}