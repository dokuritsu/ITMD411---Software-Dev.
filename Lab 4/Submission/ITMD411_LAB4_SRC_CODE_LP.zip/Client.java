package lab4;

public abstract class Client{
/**
 *  Read from csv file
 */
public abstract void readData();

/**
 *  Print information from csv
 */
public abstract void printData();
}