Project: Bank Account Simulator Program
--------------------------------------------------------------------------------------------------------------------------
Objective: Write a program that performs various bank transactions
--------------------------------------------------------------------------------------------------------------------------
Description: Bank of WCC requests a program that will create a bank account and perform various bank transcations, such as creating an initial balance, entering deposits or withdrawals. The program will print the account information including the interest at various interest rates.
